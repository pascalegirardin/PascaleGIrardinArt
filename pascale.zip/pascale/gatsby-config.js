const rucksackCss = require(`rucksack-css`)
const lost = require(`lost`)
const cuid = require('cuid')

let activeEnv = process.env.ACTIVE_ENV || process.env.NODE_ENV || 'development'

console.log(`Using environment config: '${activeEnv}'`)

require('dotenv').config({
  path: `.env.${activeEnv}`,
})

module.exports = {
  siteMetadata: {
    title: 'Pascale Girardin',
  },
  plugins: [
    {
      resolve: `gatsby-source-wordpress`,
      options: {
        baseUrl: process.env.API_URL,
        protocol: process.env.API_PROTOCOL,
        hostingWPCOM: false,
        useACF: true,
        // auth: {
        //   htaccess_user: 'admin',
        //   htaccess_pass: 'admin',
        // },
        searchAndReplaceContentUrls: {
          sourceUrl: process.env.SOURCE_URL,
          replacementUrl: process.env.REPLACEMENT_URL,
        },
        verboseOutput: true,
        excludedRoutes: [
          '/*/*/comments',
          '/*/*/comments/**',
          '/*/*/settings',
          '/*/*/users',
          '/*/*/users/**',
          '/yoast/**',
          '/akismet/**',
          '/oembed/**',
        ],
        // includedRoutes: [
        //   '/*/*/categories',
        //   '/*/*/posts',
        //   '/*/*/projects',
        //   '/*/*/pages',
        //   '/*/*/media',
        //   '/*/*/tags',
        //   '/*/*/taxonomies',
        //   '/*/*/menus',
        //   '/*/*/menus/**',
        //   '/*/*/menus/locations',
        //   '/*/*/menus/locations/**',
        //   '/*/*/menus/locations/primary',
        // ],
        normalizer: function({ entities }) {
          // Extrait les flexible_content des sections sur les Page
          // lien: https://github.com/gatsbyjs/gatsby/issues/7180#issuecomment-413115409
          return entities.map(e => {
            if (e.acf && e.acf.sections && e.acf.sections.length) {
              e.acf.components = []
              e.acf.sections.forEach(row =>
                Object.entries(row)
                  .filter(([column]) => column.includes('flexible_content'))
                  .forEach(([column, components]) => {
                    components.forEach(c => (c.cuid = cuid()))
                    row[`${column}`] = components.map(c => c.cuid)
                    e.acf.components = [...e.acf.components, ...components]
                  })
              )
            }
            return e
          })
        },
      },
    },
    `gatsby-transformer-sharp`,
    `gatsby-plugin-sharp`,
    {
      resolve: `gatsby-plugin-sass`,
      options: {
        postCssPlugins: [rucksackCss()],
        precision: 8,
      },
    },
    'gatsby-plugin-react-helmet',
    {
      resolve: `gatsby-plugin-manifest`,
      options: {
        name: 'gatsby-starter-default',
        short_name: 'starter',
        start_url: '/',
        background_color: '#ffffff',
        theme_color: '#ffffff',
        display: 'minimal-ui',
        icon: 'src/images/gatsby-icon.png', // This path is relative to the root of the site.
      },
    },
    'gatsby-plugin-offline',
    'gatsby-plugin-netlify-cache',
    `gatsby-plugin-netlify`,
    {
      resolve: `gatsby-plugin-canonical-urls`,
      options: {
        siteUrl: process.env.CANONICAL_URL,
      },
    },
    {
      resolve: `gatsby-plugin-google-analytics`,
      options: {
        trackingId: 'UA-XXXXXXX-1',
        // Puts tracking script in the head instead of the body
        head: false,
        // Setting this parameter is optional
        anonymize: true,
        // Setting this parameter is also optional
        respectDNT: true,
        // Avoids sending pageview hits from custom paths
        // exclude: ['/preview/**', '/do-not-track/me/too/'],
        // // Enables Google Optimize using your container Id
        // optimizeId: 'YOUR_GOOGLE_OPTIMIZE_TRACKING_ID',
        // // Any additional create only fields (optional)
        sampleRate: 5,
        siteSpeedSampleRate: 10,
        cookieDomain: 'pascalegirardin.art',
      },
    },
  ],
}
