import React, { Component } from 'react'
import PropTypes from 'prop-types'
import close from '../images/close.svg'
import leftArrow from '../images/left-arrow.svg'
import rightArrow from '../images/right-arrow.svg'
import { navigate } from 'gatsby'
import get from 'lodash/get'
import classnames from 'classnames'
import Observer from '@researchgate/react-intersection-observer'

export class Article extends Component {
  handleIntersection = event => {
    // console.log(event.isIntersecting)
    event.isIntersecting && this.props.close()
  }

  render() {
    const { header, children, edges, pageContext, isModal } = this.props

    let index
    let prev
    let next
    let nextLink
    let prevLink

    if (edges) {
      index = edges.findIndex(({ node }) => node.id === pageContext.id)
      prev = index - 1 < 1 ? edges.length - 1 : index - 1
      next = index + 1 === edges.length ? 0 : index + 1

      nextLink = get(edges, `${next}.node.link`)
      prevLink = get(edges, `${prev}.node.link`)
    }

    const options = {
      onChange: this.handleIntersection,
      root: '.page-modal__content',
      rootMargin: '0% 0% -90%',
    }

    return (
      <div
        id="article"
        className={classnames('article', {
          'article--modal': isModal,
        })}
      >
        <div className="article__wrap">
          <div className="article__header">{header}</div>
          <div className="article__main">
            <div className="article__nav">
              <ul className="article-nav">
                {isModal && (
                  <li className="article-nav-item">
                    <button onClick={this.props.close}>
                      <img src={close} alt="close project" />
                    </button>
                  </li>
                )}
                {isModal && prevLink && (
                  <li className="article-nav-item">
                    <button onClick={() => navigate(prevLink)}>
                      <img src={leftArrow} alt="previous project" />
                    </button>
                  </li>
                )}
                {isModal && nextLink && (
                  <li className="article-nav-item">
                    <button onClick={() => navigate(nextLink)}>
                      <img src={rightArrow} alt="next project" />
                    </button>
                  </li>
                )}
              </ul>
            </div>
            <div className="article__content">{children}</div>
          </div>
        </div>
        {isModal && (
          <Observer {...options}>
            <button className="article__close" onClick={this.props.close} />
          </Observer>
        )}
      </div>
    )
  }
}

Article.defaultProps = {
  isModal: false,
}

Article.propTypes = {
  children: PropTypes.element.isRequired,
  header: PropTypes.element.isRequired,
}

export default Article
