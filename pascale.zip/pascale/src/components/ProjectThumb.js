import React from 'react'
import classnames from 'classnames'
import { Link } from '../i18n'
import Img from 'gatsby-image'

const ProjectThumb = ({ children, classMod }) => {
  return (
    <div className={classnames('project-thumb', `project-thumb--${classMod}`)}>
      {children}
    </div>
  )
}

// 5, 6, 9, 10, 12
// left, center, right

export const ProjectThumbImage = ({
  size,
  align,
  row,
  to,
  locale,
  caption,
  title,
  fluid,
  pixel,
  nextLink,
  prevLink,
  onClick,
}) => {
  let image = null

  const cap = React.isValidElement(caption) ? (
    <figcaption className="project-thumb__caption">{caption}</figcaption>
  ) : (
    <figcaption className="project-thumb__caption">
      {title && (
        <>
          <span dangerouslySetInnerHTML={{ __html: title }} /> –{' '}
        </>
      )}
      <span dangerouslySetInnerHTML={{ __html: caption }} />
    </figcaption>
  )

  if (fluid) {
    let base64 = fluid.base64

    if (pixel) {
      base64 = pixel.src
      fluid.base64 = base64
    }

    image = (
      <figure>
        <Img fluid={fluid} />
        {caption && cap}
      </figure>
    )
  }

  if (to) {
    image = (
      <ProjectThumbLink to={to} state={{ nextLink, prevLink }} locale={locale}>
        {image}
      </ProjectThumbLink>
    )
  }

  return (
    <div
      className={classnames(
        'project-thumb__image',
        `project-thumb__image--${size}`,
        `project-thumb__image--${align}`,
        { 'project-thumb__image--row': !!row }
      )}
      onClick={onClick}
    >
      {image}
    </div>
  )
}

export const ProjectThumbRow = ({ children, align }) => {
  let classname = 'project-thumb__row'

  if (align) {
    classname = classname.concat(` project-thumb__row--${align}`)
  }

  return <div className={classname}>{children}</div>
}

const ProjectThumbLink = ({ children, to, state, locale }) => {
  return (
    <Link className="project-thumb__link" to={to} state={state} locale={locale}>
      {children}
    </Link>
  )
}

export const ProjectThumbText = ({
  size,
  align,
  row,
  to,
  locale,
  children,
  nextLink,
  prevLink,
}) => {
  let text = children

  if (to) {
    text = (
      <ProjectThumbLink
        to={to}
        state={{
          nextLink,
          prevLink,
        }}
        locale={locale}
      >
        {children}
      </ProjectThumbLink>
    )
  }

  return (
    <ProjectThumbRow>
      <div
        className={classnames(
          'project-thumb__text',
          `project-thumb__text--${size}`,
          `project-thumb__text--${align}`,
          { 'project-thumb__text--row': !!row }
        )}
      >
        {text}
      </div>
    </ProjectThumbRow>
  )
}

export default ProjectThumb
