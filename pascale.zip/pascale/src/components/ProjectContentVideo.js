import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Vimeo from '@u-wave/react-vimeo'

export default ({ vimeoUrl }) => (
  <div className="project-content__block project-content__block--video">
    <div class="video">
      <Vimeo video={vimeoUrl} />
    </div>
  </div>
)
