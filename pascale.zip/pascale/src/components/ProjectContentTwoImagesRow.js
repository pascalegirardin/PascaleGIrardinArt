import React, { Component } from 'react'
import PropTypes from 'prop-types'

import ProjectThumb, {
  ProjectThumbImage,
  ProjectThumbRow,
} from '../components/ProjectThumb'

export default ({ left, right }) => {
  return (
    <div className="project-content__block project-content__block--images">
      <ProjectThumb classMod="content">
        <ProjectThumbRow>
          <ProjectThumbImage
            size={parseInt(left.size)}
            align={'left'}
            caption={left.image.caption}
            title={left.image.title}
            fluid={
              left.image.localFile &&
              left.image.localFile.childImageSharp &&
              left.image.localFile.childImageSharp.fluid
            }
            pixel={
              left.image.localFile &&
              left.image.localFile.childImageSharp &&
              left.image.localFile.childImageSharp.pixel
            }
            row={false}
            onClick={left.onClick}
          />
          <ProjectThumbImage
            size={parseInt(right.size)}
            align={'right'}
            caption={right.image.caption}
            title={right.image.title}
            fluid={
              right.image.localFile &&
              right.image.localFile.childImageSharp &&
              right.image.localFile.childImageSharp.fluid
            }
            pixel={
              right.image.localFile &&
              right.image.localFile.childImageSharp &&
              right.image.localFile.childImageSharp.pixel
            }
            row={false}
            onClick={right.onClick}
          />
        </ProjectThumbRow>
      </ProjectThumb>
    </div>
  )
}
