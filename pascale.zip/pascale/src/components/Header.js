import React, { Component } from 'react'
import Logotype from './Logotype'
import menu from '../images/menu.svg'
import close from '../images/close.svg'
import Modal from 'react-modal'
import { Link, graphql, StaticQuery } from 'gatsby'
import LangNav from './LangNav'
import { extractMenusItemsFromLabel } from '../lib/utils'

Modal.setAppElement(`#___gatsby`)

const modalStyles = {
  overlay: {
    position: `fixed`,
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    width: '100vw',
    backgroundColor: `transparent`,
  },
  content: {
    position: `asbolute`,
    border: `none`,
    background: `#fff`,
    top: 0,
    bottom: 0,
    right: 0,
    left: 0,
    width: '100vw',
    height: '100vh',
    overflow: `auto `,
    WebkitOverflowScrolling: `touch`,
  },
}

class Header extends Component {
  state = {
    open: false,
  }

  constructor(props) {
    super(props)
    this.close = this.close.bind(this)
    this.close = this.close.bind(this)
  }

  handleClick() {
    this.setState({
      open: true,
    })
  }

  close() {
    this.setState({
      open: false,
    })
  }

  render() {
    const { siteTitle, pageContext } = this.props

    return (
      <StaticQuery
        query={graphql`
          query {
            allWordpressWpApiMenusMenusItems {
              edges {
                node {
                  slug
                  wordpress_id
                  name
                  count
                  items {
                    order
                    title
                    url
                  }
                }
              }
            }
            allWordpressWpApiMenusMenuLocations {
              edges {
                node {
                  wordpress_id
                  label
                }
              }
            }
          }
        `}
        render={data => {
          const items = extractMenusItemsFromLabel(
            `primary-${pageContext.locale}`,
            data
          )

          return (
            <header className="header">
              <div className="header__visible">
                <h1 className="header__title">
                  <Logotype siteTitle={siteTitle} locale={pageContext.locale} />
                </h1>
                <div className="header__right">
                  <LangNav pageContext={pageContext} />
                  {!this.state.open && (
                    <button
                      type="button"
                      className="header__toggle"
                      onClick={this.handleClick.bind(this)}
                    >
                      <img src={menu} alt="open menu" />
                    </button>
                  )}
                </div>
              </div>
              <Modal
                isOpen={this.state.open}
                onRequestClose={this.close}
                style={modalStyles}
                contentLabel="Modal"
                htmlOpenClassName="ReactModal__Html--open"
                closeTimeoutMS={350}
                className="header__modal"
                overlayClassName="header__overlay"
              >
                <nav className="nav">
                  <button
                    type="button"
                    className="header__toggle"
                    onClick={this.close}
                  >
                    <img src={close} alt="close menu" />
                  </button>
                  {items && (
                    <ul>
                      {items.map((item, i) => (
                        <li key={i}>
                          <Link
                            to={item.url}
                            activeClassName="active"
                            onClick={this.close}
                          >
                            {item.title}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  )}
                </nav>
              </Modal>
            </header>
          )
        }}
      />
    )
  }
}

export default Header
