import React from "react"
import Modal from "react-modal"
import mousetrap from "mousetrap"
import * as PropTypes from "prop-types"
import { navigate } from "gatsby"

// let posts

Modal.setAppElement(`#___gatsby`)

const modalStyles = {
  overlay: {
    position: `fixed`,
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    width: '100vw',
    backgroundColor: `transparent`,
  },
  content: {
    position: `asbolute`,
    border: `none`,
    background: `none`,
    padding: 0,
    top: 0,
    bottom: 0,
    right: 0,
    left: 0,
    width: '100vw',
    height: '100vh',
    overflow: `auto `,
    WebkitOverflowScrolling: `touch`,
  },
}

class AppModal extends React.Component {
  static propTypes = {
    isOpen: PropTypes.bool,
    location: PropTypes.object.isRequired,
  }

  state = {
    isOpen: true,
  }

  // constructor(props) {
  //   super(props)
  //   this.dialog = React.createRef()
  // }

  constructor(props) {
    super(props)

    this.closeModal = this.closeModal.bind(this)
  }

  componentDidMount() {
    mousetrap.bind(`left`, () => this.previous())
    mousetrap.bind(`right`, () => this.next())
    mousetrap.bind(`spacebar`, () => this.next())

    // this.setState({
    //   isOpen: this.props.isOpen,
    // })

    // this.dialog.current.on('hide', () => push(`/`))
    // this.props.isOpen ? this.dialog.current.show() : this.dialog.current.hide()
  }

  // componentWillReceiveProps(nextProps) {
  //   if (nextProps.isOpen !== this.props.isOpen) {
  //     nextProps.isOpen ? this.current.dialog.show() : this.current.dialog.hide()
  //   }
  // }

  componentWillUnmount() {
    mousetrap.unbind(`left`)
    mousetrap.unbind(`right`)
    mousetrap.unbind(`spacebar`)
  }

  // findCurrentIndex() {
  //   let index
  //   index = findIndex(
  //     posts,
  //     post => post.id === this.props.location.pathname.split(`/`)[1]
  //   )

  //   return index
  // }

  next(e) {
    // if (e) {
    //   e.stopPropagation()
    // }
    // const currentIndex = this.findCurrentIndex()
    // if (currentIndex || currentIndex === 0) {
    //   let nextPost
    //   // Wrap around if at end.
    //   if (currentIndex + 1 === posts.length) {
    //     nextPost = posts[0]
    //   } else {
    //     nextPost = posts[currentIndex + 1]
    //   }
    //   push(`/${nextPost.id}/`)
    // }
  }

  previous(e) {
    // if (e) {
    //   e.stopPropagation()
    // }
    // const currentIndex = this.findCurrentIndex()
    // if (currentIndex || currentIndex === 0) {
    //   let previousPost
    //   // Wrap around if at start.
    //   if (currentIndex === 0) {
    //     previousPost = posts.slice(-1)[0]
    //   } else {
    //     previousPost = posts[currentIndex - 1]
    //   }
    //   push(`/${previousPost.id}/`)
    // }
  }

  closeModal() {
    this.setState({
      isOpen: false,
    })
    // console.log('fudge')
    setTimeout(() => navigate(window.prevLocation ? window.prevLocation : '/'), 350)
  }


  render() {

    // const child = React.cloneElement(this.props.children, {
    //   closeModal: "chien",
    // })
    // console.log(child)

    return (
            <Modal
              isOpen={this.state.isOpen}
              onRequestClose={this.closeModal}
              style={modalStyles}
              contentLabel="Modal"
              htmlOpenClassName="ReactModal__Html--open"
              closeTimeoutMS={350}
              className="page-modal__content"
              overlayClassName="page-modal__overlay"
              portalClassName="ReactModalPortal page-modal"
            >
              <div
                // onClick={() => push(`/`)}
                // css={{
                //   display: `flex`,
                //   position: `relative`,
                //   height: `100vh`,
                // }}
              >
                  {/* <CaretLeft
                    data-testid="previous-post"
                    css={{
                      cursor: `pointer`,
                      fontSize: `50px`,
                      color: `rgba(255,255,255,0.7)`,
                      userSelect: `none`,
                    }}
                    onClick={e => this.previous(e)}
                  /> */}
                    {React.cloneElement(this.props.children, {
                      close: this.closeModal,
                    })}
                  {/* <CaretRight
                    data-testid="next-post"
                    css={{
                      cursor: `pointer`,
                      fontSize: `50px`,
                      color: `rgba(255,255,255,0.7)`,
                      userSelect: `none`,
                    }}
                    onClick={e => this.next(e)}
                  /> */}
                </div>
                {/* <Close
                  data-testid="modal-close"
                  onClick={() => push(`/`)}
                  css={{
                    cursor: `pointer`,
                    color: `rgba(255,255,255,0.8)`,
                    fontSize: `30px`,
                    position: `absolute`,
                    // top: rhythm(1 / 4),
                    // right: rhythm(1 / 4),
                  }}
                /> */}
            </Modal>
    )
  }
}

export default AppModal
