import React from 'react'
import { Link } from '../i18n'

const Logotype = ({ siteTitle, locale }) => {
  return (
    <div className="logotype">
      <Link to="/" locale={locale}>
        {siteTitle}
      </Link>
    </div>
  )
}

export default Logotype
