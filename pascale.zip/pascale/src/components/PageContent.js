import React, { Component } from 'react'
import PropTypes from 'prop-types'

import ProjectContentSlider from './ProjectContentSlider'
import ProjectContentText from './ProjectContentText'
import ProjectContentOneImageRow from './ProjectContentOneImageRow'
import ProjectContentTwoImagesRow from './ProjectContentTwoImagesRow'

export default class PageContent extends Component {
  render() {
    const { content, components } = this.props

    return (
      <div className="project-content project-content--page">
        {content.map((c, i) => {
          const layout = components.filter(obj => obj.cuid === c)
          if (layout[0].__typename === 'WordPressAcf_text') {
            return <ProjectContentText key={i} text={layout[0].text_content} />
          }
          if (layout[0].__typename === 'WordPressAcf_slider') {
            return <ProjectContentSlider key={i} images={layout[0].images} />
          }
          if (layout[0].__typename === 'WordPressAcf_one_image_row') {
            return <ProjectContentOneImageRow key={i} {...layout[0]} />
          }
          if (layout[0].__typename === 'WordPressAcf_two_images_row') {
            return <ProjectContentTwoImagesRow key={i} {...layout[0]} />
          }
          return null
        })}
      </div>
    )
  }
}
