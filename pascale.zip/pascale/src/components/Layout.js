import React from 'react'
import PropTypes from 'prop-types'
import Helmet from 'react-helmet'
import { StaticQuery, graphql, PageRenderer } from 'gatsby'
import Header from './Header'
import '../styles/main.scss'
import Footer from './Footer'
import { get_language } from '../i18n'
// import withModalState from './withModalState'

let Modal
import(`./Modal`).then(modal => {
  Modal = modal.default
})

let windowWidth

class Layout extends React.Component {
  render() {
    const { location, children, pageContext } = this.props

    let isModal = false

    if (!windowWidth && typeof window !== `undefined`) {
      windowWidth = window.innerWidth
    }

    // if (this.props.isModal && windowWidth > 750) {
    //   isModal = true
    // }

    let pathname = '/'

    if (typeof window !== 'undefined') {
      if (!isModal) {
        window.prevLocation = location.pathname
      }
      pathname = window.prevLocation
    }

    return (
      <StaticQuery
        query={graphql`
          query PascaleGirardinQuery {
            site {
              siteMetadata {
                title
              }
            }
            allWordpressPost {
              edges {
                node {
                  id
                  slug
                  date
                  link
                }
              }
            }
            allWordpressWpProjects {
              edges {
                node {
                  id
                  slug
                  link
                  date
                }
              }
            }
          }
        `}
        render={data => {
          const edges = data.allWordpressWpProjects.edges.concat(
            data.allWordpressPost.edges
          )

          // sort all nodes by date and reverse order
          edges
            .sort((a, b) => {
              const dateA = new Date(a.node.date)
              const dateB = new Date(b.node.date)
              return dateA - dateB
            })
            .reverse()

          if (isModal && Modal) {
            const fragment = (
              <React.Fragment>
                <PageRenderer location={{ pathname }} />
                <Modal isOpen={true} location={location}>
                  {React.cloneElement(children, { edges, pageContext })}
                </Modal>
              </React.Fragment>
            )
            return fragment
          }

          return (
            <div>
              <Helmet>
                <html lang={get_language(pageContext.locale)} />
              </Helmet>
              <Header
                siteTitle={data.site.siteMetadata.title}
                pageContext={pageContext}
              />
              <main id="main">{children}</main>
              <Footer
                siteTitle={data.site.siteMetadata.title}
                pageContext={pageContext}
              />
            </div>
          )
        }}
      />
    )
  }
}

Layout.propTypes = {
  children: PropTypes.node.isRequired,
}

export default Layout
