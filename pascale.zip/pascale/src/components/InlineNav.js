import React, { Component } from 'react'

export class InlineNav extends Component {
  render() {
    const { title, items } = this.props

    return (
      <nav className="inline-nav">
        <div className="inline-nav__title">{title}</div>
        {items && <ul className="inline-nav__items">
          {items.map((i, index) => <li key={index} className="inline-nav__item">{i}</li>)}
        </ul>}
      </nav>
    )
  }
}

export default InlineNav
