import React, { Component } from 'react'
import { Link, languages } from '../i18n'
import PropTypes from 'prop-types'

class LangNav extends Component {
  render() {
    const { pageContext } = this.props

    if (!pageContext.locale) {
      return null
    }

    return (
      <ul className="lang">
        {languages.map(lang => {
          let translation = false

          if (pageContext.translations) {
            translation = pageContext.translations.find(
              t => t.locale === lang.locale
            )
          }

          const path = translation
            ? { to: translation.path }
            : { to: '/', locale: lang.locale }

          return (
            <li
              key={lang.locale}
              aria-hidden={lang.locale === pageContext.locale}
            >
              <Link {...path} state={{
                modal: false,
              }}>{lang.text}</Link>
            </li>
          )
        })}
      </ul>
    )
  }
}

LangNav.propTypes = {
  pageContext: PropTypes.object.isRequired,
}

export default LangNav
