import React from 'react'
import PropTypes from 'prop-types'

const LoadMore = ({ handleClick }) => (
  <button className="loadmore" onClick={handleClick}>PLUS<br/>↓</button>
)

LoadMore.propTypes = {
  handleClick: PropTypes.func.isRequired,
}

export default LoadMore
