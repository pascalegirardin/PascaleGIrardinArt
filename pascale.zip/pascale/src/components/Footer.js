import React, { Component } from 'react'
import Logotype from './Logotype'
import InlineNav from './InlineNav'
import { StaticQuery, graphql } from 'gatsby'
import { extractMenusItemsFromLabel } from '../lib/utils'
import { Link } from '../i18n'

export default class Footer extends Component {
  render() {
    const { siteTitle, pageContext } = this.props

    return (
      <StaticQuery
        query={graphql`
          query {
            allWordpressWpApiMenusMenusItems {
              edges {
                node {
                  slug
                  wordpress_id
                  name
                  count
                  items {
                    order
                    title
                    url
                    attr
                    target
                    classes
                    wordpress_children {
                      order
                      title
                      url
                      attr
                      target
                      classes
                    }
                  }
                }
              }
            }
            allWordpressWpApiMenusMenuLocations {
              edges {
                node {
                  wordpress_id
                  label
                }
              }
            }
          }
        `}
        render={data => {
          const items = extractMenusItemsFromLabel(
            `footer-${pageContext.locale}`,
            data
          )

          return (
            <footer className="footer">
              <div className="footer__logotype">
                <Logotype siteTitle={siteTitle} />
              </div>
              <ul className="footer__nav">
                {items &&
                  items.map((item, i) => {
                    return (
                      <li className="footer__nav-item" key={i}>
                        <InlineNav
                          title={
                            <Link
                              to={item.url}
                              activeClassName="active"
                              locale={pageContext.locale}
                            >
                              {item.title}
                            </Link>
                          }
                          items={
                            item.wordpress_children &&
                            item.wordpress_children.map(child => (
                              <Link
                                to={child.url}
                                activeClassName="active"
                                locale={pageContext.locale}
                              >
                                {child.title}
                              </Link>
                            ))
                          }
                        />
                      </li>
                    )
                  })}
              </ul>
            </footer>
          )
        }}
      />
    )
  }
}
