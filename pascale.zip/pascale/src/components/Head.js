import React from 'react'
import Helmet from 'react-helmet'
import { intlShape } from 'react-intl'
import { languages } from '../i18n'
import PropTypes from 'prop-types'

const defaultShare = '/default-share.jpg'

const Head = (props, context) => {
  const image = props.image || defaultShare
  const description = props.description || context.intl.messages.siteDescription
  const title = props.title
    ? `${props.title} | ${context.intl.messages.siteTitle}`
    : context.intl.messages.siteTitle
  const canonical = `${process.env.CANONICAL_URL}${props.pathname}`
  const locale = languages.find(l => l.slug === context.intl.locale).locale
  // const pageContext = props.pageContext

  let links = []

  if (props.pageContext && props.pageContext.translations) {
    links = props.pageContext.translations.map(t => {
      return {
        rel: 'alternate',
        hreflang: t.locale.replace('_', '-'),
        href: `${process.env.CANONICAL_URL}${t.path}`,
      }
    })
  }

  return (
    <Helmet
      title={title}
      meta={
        [
          { name: 'description', content: description },
          { property: 'og:image', content: image },
          { property: 'og:description', content: description },
          { property: 'og:type', content: 'website' },
          { property: 'og:title', content: title },
          { property: 'og:url', content: canonical },
          { property: 'og:locale', content: locale },
          { property: 'twitter:card', content: 'summary' },
        ] // { name: 'keywords', content: 'sample, something' },
      }
      link={
        [
          { rel: 'canonical', href: canonical },
          {
            rel: 'alternate',
            hreflang: locale.replace('_', '-'),
            href: canonical,
          },
          ...links,
        ] // fr_CA -> fr-CA
      }
    >
      <link rel="icon" href="/favicon.ico" />
      <link
        rel="icon"
        type="image/png"
        sizes="32x32"
        href="/favicon-32x32.png"
      />
      <link
        rel="icon"
        type="image/png"
        sizes="16x16"
        href="/favicon-16x16.png"
      />
    </Helmet>
  )
}

Head.contextTypes = {
  intl: intlShape,
}

Head.propTypes = {
  pageContext: PropTypes.object.isRequired,
  pathname: PropTypes.string.isRequired,
  title: PropTypes.string,
  image: PropTypes.string,
  description: PropTypes.string,
}

export default Head

/**
 * DOCUMENTATION
 *
 * Twitter
 * https://developer.twitter.com/en/docs/tweets/optimize-with-cards/guides/getting-started
 *
 * Facebook
 * https://developers.facebook.com/docs/sharing/webmasters/
 */
/**
 * url
 * title
 * description
 * image // og:image 1200x630
 * og:type = website
 * og:locale = fr_CA
 * app_id
 */

/**
<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<link rel="manifest" href="/site.webmanifest">
<link rel="mask-icon" href="/safari-pinned-tab.svg" color="#000000">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="theme-color" content="#ffffff">
  */
