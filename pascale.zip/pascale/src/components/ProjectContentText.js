import React, { Component } from 'react'
import PropTypes from 'prop-types'

export default ({ text }) => (
  <div
    className="project-content__block project-content__block--text"
    dangerouslySetInnerHTML={{ __html: text }}
  />
)
