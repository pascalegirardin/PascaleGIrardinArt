import React, { Component } from 'react'
import PropTypes from 'prop-types'

import ProjectContentSlider from './ProjectContentSlider'
import ProjectContentText from './ProjectContentText'
import ProjectContentOneImageRow from './ProjectContentOneImageRow'
import ProjectContentTwoImagesRow from './ProjectContentTwoImagesRow'
import ProjectContentVideo from './ProjectContentVideo'

export default class ProjectContent extends Component {
  constructor(props) {
    super(props)

    this.state = {
      scrollTop: null,
    }
  }

  render() {
    const { content } = this.props

    return (
      <div className="project-content">
        {content.map((layout, i) => {
          if (layout.__typename === 'WordPressAcf_text') {
            return <ProjectContentText key={i} text={layout.text_content} />
          }

          if (layout.__typename === 'WordPressAcf_video') {
            return <ProjectContentVideo key={i} vimeoUrl={layout.vimeo_url} />
          }

          if (layout.__typename === 'WordPressAcf_slider') {
            let images = layout.images

            return <ProjectContentSlider key={i} images={images} />
          }

          if (layout.__typename === 'WordPressAcf_one_image_row') {
            const image = layout.image

            return (
              <ProjectContentOneImageRow
                key={i}
                {...Object.assign(layout, { image })}
              />
            )
          }

          if (layout.__typename === 'WordPressAcf_two_images_row') {
            const left = layout.left
            const right = layout.right

            return (
              <ProjectContentTwoImagesRow
                key={i}
                {...Object.assign(layout, { left, right })}
              />
            )
          }
          return null
        })}
      </div>
    )
  }
}

ProjectContent.propTypes = {
  content: PropTypes.array.isRequired,
}
