import React from 'react'

const NewsHeader = ({ title, title2, dates, subtitle, classMod }) => {
	return <div className={`news-header news-header--${classMod}`}>
      <h2 className="news-header__title">
        <span dangerouslySetInnerHTML={{ __html: title }} />
        {title2 && <div className="news-header__subtitle" dangerouslySetInnerHTML={{ __html: title2 }} />}
      </h2>
      {(dates || subtitle) && <ul className="news-header__detail">
          {subtitle && <li dangerouslySetInnerHTML={{ __html: subtitle }} />}
          {dates && <li className="dates" dangerouslySetInnerHTML={{ __html: dates }} />}
        </ul>}
    </div>
}

NewsHeader.defaultProps = {
  classMod: 'none',
}

export default NewsHeader
