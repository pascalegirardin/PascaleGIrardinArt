import React, { Component } from 'react'
import PropTypes from 'prop-types'

import ProjectThumb, {
  ProjectThumbImage,
  ProjectThumbRow,
} from './ProjectThumb'

export default ({ size, align, image, openLightbox }) => {
  return (
    <div className="project-content__block project-content__block--images">
      <ProjectThumb classMod="content">
        <ProjectThumbRow align={align}>
          <ProjectThumbImage
            size={parseInt(size)}
            align={align}
            caption={image.caption}
            title={image.title}
            fluid={
              image.localFile &&
              image.localFile.childImageSharp &&
              image.localFile.childImageSharp.fluid
            }
            pixel={
              image.localFile &&
              image.localFile.childImageSharp &&
              image.localFile.childImageSharp.pixel
            }
            row={true}
            onClick={image.onClick}
          />
        </ProjectThumbRow>
      </ProjectThumb>
    </div>
  )
}
