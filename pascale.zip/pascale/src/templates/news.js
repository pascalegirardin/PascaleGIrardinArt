import React, { Component } from 'react'
import { graphql } from 'gatsby'
import PropTypes from 'prop-types'
import Layout from '../components/Layout'
import Article from '../components/Article'
import NewsHeader from '../components/NewsHeader'
import Head from '../components/Head'
import { withIntl } from '../i18n'

class PostTemplate extends Component {
  render() {
    let isModal = false

    if (
      typeof window !== `undefined` &&
      window.innerWidth > 750 &&
      window.___APP_INITIAL_RENDER_COMPLETE &&
      this.props.location &&
      this.props.location.state &&
      this.props.location.state.modal !== false
    ) {
      isModal = true
    }

    const {
      data: { wordpressPost: post },
      location,
      pageContext,
    } = this.props

    return (
      <Layout location={location} isModal={isModal} pageContext={pageContext}>
        <Article
          isModal={isModal}
          header={
            <NewsHeader
              title={post.title}
              title2={post.acf.title_2}
              subtitle={post.acf.subtitle}
              dates={post.acf.dates}
              classMod="single"
            />
          }
        >
          <div className="news">
            <Head
              pathname={location.pathname}
              pageContext={pageContext}
              title={post.title}
              description={post.excerpt}
            />
            <div className="news__content">
              <div dangerouslySetInnerHTML={{ __html: post.content }} />
            </div>
          </div>
        </Article>
      </Layout>
    )
  }
}

PostTemplate.propTypes = {
  data: PropTypes.object.isRequired,
  edges: PropTypes.array,
}

export default withIntl(PostTemplate)

export const pageQuery = graphql`
  query($id: String!) {
    wordpressPost(id: { eq: $id }) {
      id
      title
      slug
      type
      date
      link
      type
      content
      excerpt
      acf {
        title_2
        subtitle
        dates
      }
    }
    site {
      siteMetadata {
        title
      }
    }
  }
`
