import React, { Component } from 'react'
import { graphql } from 'gatsby'
import PropTypes from 'prop-types'
import Layout from '../components/Layout'
import ProjectHeader from '../components/ProjectHeader'
import ProjectThumb, { ProjectThumbImage } from '../components/ProjectThumb'
import ProjectContent from '../components/ProjectContent'
import Article from '../components/Article'
import Head from '../components/Head'
import { withIntl } from '../i18n'
import get from 'lodash/get'

class ProjectTemplate extends Component {
  render() {
    let isModal = false

    if (
      typeof window !== `undefined` &&
      window.innerWidth > 750 &&
      window.___APP_INITIAL_RENDER_COMPLETE &&
      this.props.location &&
      this.props.location.state &&
      this.props.location.state.modal !== false
    ) {
      isModal = true
    }

    const {
      pageContext,
      location,
      data: { wordpressWpProjects: project },
    } = this.props

    return (
      <Layout location={location} isModal={isModal} pageContext={pageContext}>
        <Article
          isModal={isModal}
          header={
            <ProjectHeader
              title={project.title}
              subtitle={project.acf.subtitle}
              place={project.acf.place}
              dates={project.acf.dates}
              classMod="single"
            />
          }
        >
          <div className="project">
            {
              <Head
                pathname={location.pathname}
                pageContext={pageContext}
                title={project.title}
                image={get(
                  project,
                  'featured_media.localFile.childImageSharp.meta.src',
                  false
                )}
                description={project.excerpt}
              />
            }
            {project.featured_media && (
              <div className="project__thumb">
                <ProjectThumb classMod="header">
                  <ProjectThumbImage
                    size={project.acf.size}
                    align="right"
                    caption={project.featured_media.caption}
                    title={project.featured_media.title}
                    fluid={
                      project.featured_media.localFile &&
                      project.featured_media.localFile.childImageSharp &&
                      project.featured_media.localFile.childImageSharp.fluid
                    }
                    pixel={
                      project.featured_media.localFile &&
                      project.featured_media.localFile.childImageSharp &&
                      project.featured_media.localFile.childImageSharp.pixel
                    }
                  />
                </ProjectThumb>
              </div>
            )}
            <div className="project__content">
              {project.acf && project.acf.flexible_content_project && (
                <ProjectContent
                  content={project.acf.flexible_content_project}
                  isModal={isModal}
                />
              )}
            </div>
          </div>
        </Article>
      </Layout>
    )
  }
}

ProjectTemplate.propTypes = {
  data: PropTypes.object.isRequired,
  edges: PropTypes.array,
}

export default withIntl(ProjectTemplate)

export const pageQuery = graphql`
  query($id: String!) {
    wordpressWpProjects(id: { eq: $id }) {
      title
      excerpt
      featured_media {
        localFile {
          childImageSharp {
            fluid(maxWidth: 1500) {
              ...GatsbyImageSharpFluid_noBase64
            }
            pixel: fixed(width: 1, height: 1) {
              ...GatsbyImageSharpFixed_noBase64
            }
            meta: fixed(width: 900) {
              ...GatsbyImageSharpFixed_noBase64
            }
          }
        }
        caption
        title
      }
      acf {
        size
        subtitle
        dates
        place
        flexible_content_project {
          __typename
          ... on WordPressAcf_text {
            text_content
          }
          ... on WordPressAcf_video {
            vimeo_url
          }
          ... on WordPressAcf_slider {
            images {
              id
              caption
              title
              alt_text
              media_details {
                width
                height
              }
              localFile {
                childImageSharp {
                  original {
                    width
                    height
                    src
                  }
                  landscape: fluid(maxWidth: 1500) {
                    ...GatsbyImageSharpFluid_withWebp_noBase64
                  }
                  portrait: fluid(maxWidth: 1500) {
                    ...GatsbyImageSharpFluid_withWebp_noBase64
                  }
                  pixel: fixed(width: 1, height: 1) {
                    ...GatsbyImageSharpFixed_noBase64
                  }
                }
              }
            }
          }
          ... on WordPressAcf_one_image_row {
            size
            align
            image {
              id
              caption
              title
              alt_text
              localFile {
                childImageSharp {
                  original {
                    width
                    height
                    src
                  }
                  fluid(maxWidth: 1500) {
                    ...GatsbyImageSharpFluid_withWebp_noBase64
                  }
                  pixel: fixed(width: 1, height: 1) {
                    ...GatsbyImageSharpFixed_noBase64
                  }
                }
              }
            }
          }
          ... on WordPressAcf_two_images_row {
            left {
              size
              image {
                id
                caption
                title
                alt_text
                localFile {
                  childImageSharp {
                    original {
                      width
                      height
                      src
                    }
                    fluid(maxWidth: 1500) {
                      ...GatsbyImageSharpFluid_withWebp_noBase64
                    }
                    pixel: fixed(width: 1, height: 1) {
                      ...GatsbyImageSharpFixed_noBase64
                    }
                  }
                }
              }
            }
            right {
              size
              image {
                id
                caption
                title
                alt_text
                localFile {
                  childImageSharp {
                    original {
                      width
                      height
                      src
                    }
                    fluid(maxWidth: 1500) {
                      ...GatsbyImageSharpFluid_withWebp_noBase64
                    }
                    pixel: fixed(width: 1, height: 1) {
                      ...GatsbyImageSharpFixed_noBase64
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    site {
      siteMetadata {
        title
      }
    }
  }
`
