import React, { Component } from 'react'
import { graphql } from 'gatsby'
// import PostIcons from '../components/PostIcons'
import Layout from '../components/Layout'
import InlineNav from '../components/InlineNav'
import PageContent from '../components/PageContent'
import Head from '../components/Head'
import { withIntl } from '../i18n'
import Link from 'gatsby-link'

class PageTemplate extends Component {
  state = {
    current: 0,
  }

  click = current => this.setState({ current })

  componentDidMount() {
    if (this.props.location.hash) {
      this.setState({ current: parseInt(this.props.location.hash.slice(1)) })
    }
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.location.hash !== nextProps.location.hash) {
      this.setState({ current: parseInt(nextProps.location.hash.slice(1)) })

      if (typeof window !== 'undefined') {
        window.scrollTo(0, 0)
      }
    }
  }

  render() {
    const {
      pageContext,
      location,
      data: { wordpressPage },
    } = this.props

    const sections = wordpressPage.acf.sections

    let items = []

    if (sections.length > 1) {
      items = sections.map((section, index) => (
        <Link to={`${location.pathname}#${index}`} replace>
          <span
            className={index === this.state.current ? 'active' : ''}
            onClick={() => this.click(index)}
            dangerouslySetInnerHTML={{ __html: section.title }}
          />
        </Link>
      ))
    }

    return (
      <Layout location={this.props.location} pageContext={pageContext}>
        <InlineNav title={wordpressPage.title} items={items} />
        <h1
          className="visuallyhidden"
          dangerouslySetInnerHTML={{ __html: wordpressPage.title }}
        />

        <Head
          pathname={location.pathname}
          pageContext={pageContext}
          title={wordpressPage.title}
          description={wordpressPage.excerpt}
        />
        <div className="page-sections">
          <PageContent
            content={sections[this.state.current].flexible_content}
            components={wordpressPage.acf.components_page}
          />
        </div>
      </Layout>
    )
  }
}

export default withIntl(PageTemplate)

export const pageQuery = graphql`
  query($id: String!) {
    wordpressPage(id: { eq: $id }) {
      date(formatString: "MMMM DD, YYYY")
      title
      slug
      link
      excerpt
      acf {
        components_page {
          __typename
          ... on WordPressAcf_text {
            cuid
            text_content
          }
          ... on WordPressAcf_one_image_row {
            cuid
            image {
              caption
              alt_text
              localFile {
                childImageSharp {
                  fluid(maxWidth: 1280) {
                    ...GatsbyImageSharpFluid_withWebp_noBase64
                  }
                  pixel: fixed(width: 1, height: 1) {
                    ...GatsbyImageSharpFixed_noBase64
                  }
                }
              }
            }
            size
            align
          }
          ... on WordPressAcf_slider {
            cuid
            images {
              caption
              alt_text
              media_details {
                width
                height
              }
              localFile {
                childImageSharp {
                  landscape: fluid(maxWidth: 680) {
                    ...GatsbyImageSharpFluid_withWebp_noBase64
                  }
                  portrait: fluid(maxWidth: 340) {
                    ...GatsbyImageSharpFluid_withWebp_noBase64
                  }
                  pixel: fixed(width: 1, height: 1) {
                    ...GatsbyImageSharpFixed_noBase64
                  }
                }
              }
            }
          }
        }
        sections {
          title
          flexible_content
        }
      }
    }
  }
`
