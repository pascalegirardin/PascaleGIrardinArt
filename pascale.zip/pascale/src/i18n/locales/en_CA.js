module.exports = {
  siteTitle: 'Pascale Girardin',
  siteDescription: 'Visual art',
  notFound: '404 NOT FOUND',
  news: 'News',
}
