module.exports = {
  siteTitle: 'Pascale Girardin',
  siteDescription: 'Art visuel',
  notFound: '404 NOT FOUND',
  news: 'Actualités',
}
