import React, { Component } from 'react'
import Layout from '../components/Layout'
import NewsHeader from '../components/NewsHeader'
import { graphql } from 'gatsby'
import InlineNav from '../components/InlineNav'
import Head from '../components/Head'
import { withIntl, Link } from '../i18n'

class News extends Component {
  render() {
    const { data, pageContext, location } = this.props

    console.log(pageContext.locale)

    return (
      <Layout location={location} pageContext={pageContext}>
        <div className="news">
          <Head pathname={location.pathname} pageContext={pageContext} />
          <h2 className="news__heading">
            <InlineNav
              title={
                <Link to="/news" locale={pageContext.locale}>
                  {pageContext.locale === 'en_CA' ? 'News' : 'Actualités'}
                </Link>
              }
            />
          </h2>
          <div className="news__list">
            {data.allWordpressPost.edges.map(({ node }) => (
              <div key={node.id} className="news__item">
                <NewsListItem node={node} />
              </div>
            ))}
          </div>
        </div>
      </Layout>
    )
  }
}

export const NewsListItem = ({ node }) => (
  <Link to={node.link}>
    <NewsHeader
      title={node.title}
      title2={node.acf.title_2}
      subtitle={node.acf.subtitle}
      dates={node.acf.dates}
    />
  </Link>
)

export default withIntl(News)

export const pageQuery = graphql`
  query($locale: String!) {
    allWordpressPost(
      filter: { polylang_current_lang: { eq: $locale } }
      sort: { fields: [date], order: DESC }
    ) {
      edges {
        node {
          id
          title
          slug
          type
          date
          link
          type
          acf {
            title_2
            subtitle
            dates
          }
        }
      }
    }
  }
`
