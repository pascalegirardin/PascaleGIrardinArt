import React from 'react'
import { graphql } from 'gatsby'
import ProjectThumb, {
  ProjectThumbImage,
  ProjectThumbRow,
  ProjectThumbText,
} from '../components/ProjectThumb'
import Layout from '../components/Layout'
import LoadMore from '../components/LoadMore'
import ProjectHeader from '../components/ProjectHeader'
import NewsHeader from '../components/NewsHeader'
import Head from '../components/Head'
import { withIntl } from '../i18n'
import * as PropTypes from 'prop-types'
import chunk from 'lodash/chunk'

const DEFAULT_COUNT = 5

if (typeof window !== `undefined`) {
  window.postsToShow = DEFAULT_COUNT
}
class IndexPage extends React.Component {
  static propTypes = {
    location: PropTypes.object.isRequired,
    // data: PropTypes.shape({
    //   user: PropTypes.object,
    //   allPostsJson: PropTypes.object,
    // }),
  }

  constructor() {
    super()

    let postsToShow = DEFAULT_COUNT

    if (typeof window !== `undefined`) {
      postsToShow = window.postsToShow
    }

    this.state = {
      showingMore: postsToShow > DEFAULT_COUNT,
      postsToShow,
    }
  }

  update() {
    const distanceToBottom =
      document.documentElement.offsetHeight -
      (window.scrollY + window.innerHeight)
    if (this.state.showingMore && distanceToBottom < 100) {
      this.setState({ postsToShow: this.state.postsToShow + 12 })

      /**
       * Permet de conserver le même nombre de posts lorsqu'il y a
       * une boite modal d'ouverte
       */
      if (typeof window !== `undefined`) {
        window.postsToShow = this.state.postsToShow + 12
      }
    }
    this.ticking = false
  }

  handleScroll = () => {
    if (!this.ticking) {
      this.ticking = true
      requestAnimationFrame(() => this.update())
    }
  }

  componentDidMount() {
    window.addEventListener(`scroll`, this.handleScroll)
  }

  componentWillUnmount() {
    window.removeEventListener(`scroll`, this.handleScroll)
    window.postsToShow = this.state.postsToShow
  }

  render() {
    const { data, pageContext, location } = this.props

    // concatenate post and project
    const edges = data.allWordpressWpProjects.edges.concat(
      data.allWordpressPost.edges
    )

    // sort all nodes by date and reverse order
    edges
      .sort((a, b) => {
        const dateA = new Date(a.node.date)
        const dateB = new Date(b.node.date)
        return dateA - dateB
      })
      .reverse()

    const posts = edges.map(e => e.node)

    return (
      <Layout location={this.props.location} pageContext={pageContext}>
        <div className="index">
          <Head pathname={location.pathname} pageContext={pageContext} />
          <ProjectThumb classMod="index">
            {chunk(posts.slice(0, this.state.postsToShow), 3).map(
              (chunk, i) => {
                return chunk.map(node => {
                  // post
                  if (node.type === 'project') {
                    return (
                      <ProjectThumbRow key={node.id}>
                        <ProjectThumbImage
                          to={node.link}
                          size={node.acf.size}
                          align={node.acf.align}
                          locale={pageContext.locale}
                          fluid={
                            node.featured_media.localFile &&
                            node.featured_media.localFile.childImageSharp &&
                            node.featured_media.localFile.childImageSharp.fluid
                          }
                          pixel={
                            node.featured_media.localFile &&
                            node.featured_media.localFile.childImageSharp &&
                            node.featured_media.localFile.childImageSharp.pixel
                          }
                          caption={
                            <ProjectHeader
                              title={node.title}
                              subtitle={node.acf.subtitle}
                              place={node.acf.place}
                              dates={node.acf.dates}
                            />
                          }
                        />
                      </ProjectThumbRow>
                    )
                  }
                  // news
                  return (
                    <ProjectThumbText
                      key={node.id}
                      to={node.link}
                      locale={pageContext.locale}
                    >
                      <NewsHeader
                        title={node.title}
                        title2={node.acf.title_2}
                        subtitle={node.acf.subtitle}
                        dates={node.acf.dates}
                      />
                    </ProjectThumbText>
                  )
                })
              }
            )}
          </ProjectThumb>
          <div className="index__loadmore">
            {!this.state.showingMore && (
              <LoadMore
                handleClick={() => {
                  this.setState({
                    postsToShow: this.state.postsToShow + DEFAULT_COUNT,
                    showingMore: true,
                  })
                }}
              />
            )}
          </div>
        </div>
      </Layout>
    )
  }
}

export default withIntl(IndexPage)

export const pageQuery = graphql`
  query($locale: String!) {
    allWordpressPost(
      filter: { polylang_current_lang: { eq: $locale } }
      sort: { fields: [date], order: DESC }
    ) {
      edges {
        node {
          id
          title
          slug
          type
          date
          link
          type
          acf {
            title_2
            subtitle
            dates
          }
        }
      }
    }
    allWordpressWpProjects(
      filter: { polylang_current_lang: { eq: $locale } }
      sort: { fields: [date], order: DESC }
    ) {
      edges {
        node {
          id
          title
          slug
          link
          type
          date
          featured_media {
            localFile {
              childImageSharp {
                fluid(maxWidth: 1500) {
                  ...GatsbyImageSharpFluid_withWebp_noBase64
                }
                pixel: fixed(width: 1, height: 1) {
                  ...GatsbyImageSharpFixed_noBase64
                }
              }
            }
          }
          acf {
            align
            size
            subtitle
            place
            dates
          }
        }
      }
    }
  }
`
