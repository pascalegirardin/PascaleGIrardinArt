import React, { Component } from 'react'
import Layout from '../components/Layout'
import { graphql } from 'gatsby'
import InlineNav from '../components/InlineNav'
import ProjectHeader from '../components/ProjectHeader'
import Head from '../components/Head'
import { withIntl, Link } from '../i18n'
import classnames from 'classnames'

class Projects extends Component {
  state = {
    active: false,
  }

  constructor(props) {
    super(props)

    this.setActiveCategory = this.setActiveCategory.bind(this)
  }

  componentDidMount() {
    if (this.props.location.hash) {
      this.setState({ active: this.props.location.hash.slice(1) })
    }
  }

  setActiveCategory = slug => {
    if (slug === this.state.active) {
      this.setState({ active: false })
    } else {
      this.setState({ active: slug })
    }
  }

  render() {
    const { data, pageContext, location } = this.props

    const projects = data.allWordpressWpProjects.edges.filter(({ node }) => {
      const categories = node.categories

      if (!this.state.active) {
        return true
      }

      if (!categories) {
        return false
      }

      return categories.findIndex(c => c.slug === this.state.active) >= 0
    })

    return (
      <Layout location={location} pageContext={pageContext}>
        <div className="projects">
          <Head pathname={location.pathname} pageContext={pageContext} />
          <h2 className="projects__heading">
            <InlineNav
              title="projets"
              items={data.allWordpressCategory.edges.map(({ node }) => {
                return (
                  <Link to={`${location.pathname}#${node.slug}`} replace>
                    <span
                      key={node.slug}
                      onClick={() => this.setActiveCategory(node.slug)}
                      className={
                        this.state.active === node.slug ? 'active' : ''
                      }
                    >
                      {node.name}
                    </span>
                  </Link>
                )
              })}
            />
          </h2>
          <div className="projects__list">
            {projects.map(({ node }) => {
              return (
                <div className="projects__item" key={node.id}>
                  <ProjectsListItem node={node} locale={pageContext.locale} />
                </div>
              )
            })}
          </div>
        </div>
      </Layout>
    )
  }
}

export const ProjectsListItem = ({ node, locale }) => {
  return (
    <Link to={`/project/${node.slug}`} locale={locale}>
      <ProjectHeader
        title={node.title}
        subtitle={node.acf.subtitle}
        place={node.acf.places}
        dates={node.acf.dates}
      />
    </Link>
  )
}

export default withIntl(Projects)

export const pageQuery = graphql`
  query($locale: String!) {
    allWordpressWpProjects(
      filter: { polylang_current_lang: { eq: $locale } }
      sort: { fields: [date], order: DESC }
    ) {
      edges {
        node {
          id
          title
          slug
          categories {
            slug
          }
          acf {
            subtitle
            place
            dates
          }
        }
      }
    }
    allWordpressCategory(filter: { polylang_current_lang: { eq: $locale } }) {
      edges {
        node {
          slug
          name
          polylang_current_lang
        }
      }
    }
  }
`
