import React from 'react'
import Layout from '../components/Layout'
import Head from '../components/Head'
import { withIntl } from '../i18n'

const NotFoundPage = ({ location, pageContext }) => (
  <Layout location={location} pageContext={pageContext}>
    <div className="page-404">
      <Head
        pageContext={pageContext}
        pathname={location.pathname}
        title="404"
      />
      <h1>404 NOT FOUND</h1>
    </div>
  </Layout>
)

export default withIntl(NotFoundPage)
