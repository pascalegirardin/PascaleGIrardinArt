/**
 * Implement Gatsby's Browser APIs in this file.
 *
 * See: https://www.gatsbyjs.org/docs/browser-apis/
 */

// exports.shouldUpdateScroll = args => {
//   const windowWidth = window.innerWidth
//   // Scroll position only matters on mobile as on larger screens, we use a
//   // modal.
//   if (windowWidth < 750) {
//     return true
//   } else {
//     return false
//   }
// }

// exports.onInitialClientRender = () => {
//   window.___APP_INITIAL_RENDER_COMPLETE = true
// }

exports.onClientEntry = () => {
  // IntersectionObserver polyfill for gatsby-image (Safari, IE)
  if (typeof window.IntersectionObserver === `undefined`) {
    require(`intersection-observer`)
    console.log(`👍 IntersectionObserver is polyfilled`)
  }
}
